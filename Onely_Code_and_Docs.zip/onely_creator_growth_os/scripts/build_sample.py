from pathlib import Path
import csv
p=Path(__file__).resolve().parents[1]/'data'/'sample_leads.csv'
headers=['name','email','platform','profile_url','source','portfolio_url','us_case_url','us_audience_pct','conversion_case_url','conversion_note','posts_per_week','available_within_days','age_18_confirmed','consent_contact','public_post_topic','niche','preferred_channel','notes']
rows=[]
for i in range(8):
    rows.append(dict(name=f'Synthetic Applicant {i}',email=f'operator{i}@example.com',platform='TikTok, Instagram',
                profile_url=f'https://instagram.com/syntheticoperator{i}',source='community_optin' if i%2 else 'agency_referral',
                portfolio_url='https://portfolio.example/synthetic',us_case_url='https://cases.example/us-proof',
                us_audience_pct='62',conversion_case_url='https://cases.example/conversion' if i%2 else '',
                conversion_note='Affiliate funnel case available upon request',posts_per_week='5',available_within_days='3',
                age_18_confirmed='yes',consent_contact='yes',public_post_topic='public short-form social series',
                niche='lifestyle storytelling',preferred_channel='email',notes='Synthetic placeholder, not a real profile'))
# Exact duplicates and Gmail alias duplicate test.
rows.extend([rows[0].copy(),dict(rows[1],source='reviewed_outbound')])
rows.extend([dict(rows[2],name='Synthetic Gmail Alias',email='Synthetic.Test+new@gmail.com',profile_url='https://youtube.com/@syntheticAlias'),
             dict(rows[2],name='Synthetic Gmail Alias',email='synthetictest@gmail.com',profile_url='https://youtube.com/@syntheticAlias',source='agency_referral')])
rows.append(dict(rows[0],name='Invalid example',email='invalid-email',profile_url=''))
with p.open('w',newline='',encoding='utf-8') as out:
 w=csv.DictWriter(out,fieldnames=headers);w.writeheader();w.writerows(rows)
(p.parent.parent/'static'/'sample_leads.csv').write_bytes(p.read_bytes())
print(f'Saved {len(rows)} 100%-synthetic rows including duplicates and one invalid email')
