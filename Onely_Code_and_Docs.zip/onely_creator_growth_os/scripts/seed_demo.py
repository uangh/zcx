"""100% synthetic data. Resets ONLY the configured demo SQLite database."""
from __future__ import annotations
import json
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from core import connect,init_db,upsert,now,event

firsts=['Morgan','Jordan','Taylor','Casey','Riley','Cameron','Jamie','Alex','Sam','Avery','Bailey','Skyler','Parker','Dakota','Hayden','Quinn','Drew','Robin','Jessie','Emerson']
lasts=['Reed','Chen','Rivera','Patel','Wilson','Kim','Lopez','Brooks','Singh','Collins','Young','Park','Nguyen','Bailey','Turner','Flores','Hall','Price','Bennett','Carter']
niches=['lifestyle storytelling','gaming community','fashion reels','AI content','wellness content','creator economy','UGC ads','travel videos','subscription communities']
stages=['sourced']*12+['qualified']*8+['drafted']*5+['contacted']*8+['replied']*5+['interested']*4+['applied']*4+['approved']*2+['joined']*3+['activated']

def seed(reset=False):
    with connect() as con:
        init_db(con)
        if reset: con.execute('DELETE FROM events');con.execute('DELETE FROM leads');con.execute('DELETE FROM import_runs');con.execute('DELETE FROM suppression');con.commit()
        if con.execute('SELECT count(*) FROM leads').fetchone()[0]:print('Already has data. Use --reset to recreate 100% synthetic demo.');return
        for i,stage in enumerate(stages):
            source=['agency_referral','community_optin','reviewed_outbound'][i%3]
            rank=i%8
            with_proof=(rank!=6);with_conversion=(rank in [0,1,2,3,4,7]);platforms=['TikTok, Instagram, YouTube','TikTok, Instagram','YouTube, Instagram','TikTok'][rank%4]
            first=firsts[i%len(firsts)];last=lasts[(i*3)%len(lasts)];nick=first.lower()+last.lower()+str(i)
            record={'name':first+' '+last,'email':f'{nick}@example.com','platform':platforms,
                    'profile_url':f'https://instagram.com/{nick}', 'source':source,
                    'portfolio_url':f'https://portfolio.example/{nick}',
                    'us_case_url':f'https://cases.example/us/{nick}' if with_proof else '',
                    'us_audience_pct':'54' if with_proof else '25',
                    'conversion_case_url':f'https://cases.example/paid/{nick}' if with_conversion else '',
                    'conversion_note':'Experience converting newsletter subscribers' if not with_conversion else '',
                    'posts_per_week':'5' if rank!=7 else '2','available_within_days':'3' if rank<6 else '7',
                    'age_18_confirmed':'yes' if stage in ['applied','approved','joined','activated'] else '',
                    'consent_contact':'yes' if source=='community_optin' or stage not in ('sourced','qualified') else '',
                    'public_post_topic':'storytelling hooks for short-form video' if rank%2==0 else '',
                    'preferred_channel':'email','niche':niches[i%len(niches)],
                    'notes':'SYNTHETIC DEMO LEAD — no real person; no external outreach.'}
            outcome,lid=upsert(con,record)
            if outcome!='inserted':raise RuntimeError((i,outcome,lid))
            if stage not in ['sourced']:
                con.execute('UPDATE leads SET status=?,updated_at=? WHERE id=?',(stage,now(),lid))
                event(con,lid,'demo_simulated_stage',stage,'SYNTHETIC DEMO DATA; not a real campaign result')
            if stage in ['approved','joined','activated']:
                con.execute('UPDATE leads SET verified_us=1,application_reviewed=1,age_18_confirmed=1 WHERE id=?',(lid,))
            if stage in ['joined','activated']:
                con.execute('UPDATE leads SET community_joined=1 WHERE id=?',(lid,))
            if stage=='activated':
                con.execute('UPDATE leads SET creator_created=1,first_post_url=? WHERE id=?',
                            ('https://post.example/synthetic-first-post',lid))
        # A synthetic opted-out record tests hard suppression and off-ramp handling.
        record={'name':'Demo Opt Out','email':'optout.demo@example.com','platform':'TikTok',
                'profile_url':'https://tiktok.com/@syntheticoptout','source':'reviewed_outbound','niche':'creator tips'}
        _,lid=upsert(con,record)
        from core import set_status
        con.commit();set_status(con,lid,'opted_out',note='Synthetic optout to exercise safeguards')
        print('Seeded 52 synthetic leads across funnel + 1 suppressed test record.')

if __name__=='__main__':seed(reset='--reset' in sys.argv)
