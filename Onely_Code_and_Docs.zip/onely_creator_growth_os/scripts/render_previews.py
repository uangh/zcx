"""Optional visual QA helper: renders production HTML/JS against synthetic API fixtures.
Run only if playwright installed: python scripts/render_previews.py
Use live FastAPI separately for functional tests; this is an offline-browser visual check.
"""
import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from core import connect,stats,to_dict,draft_message
from playwright.sync_api import sync_playwright
with connect() as con:
    leads=[to_dict(r) for r in con.execute('SELECT * FROM leads ORDER BY score DESC').fetchall()]
    stats_data=stats(con)
    cohort=[]
    for r in con.execute("SELECT * FROM leads WHERE status IN ('applied','approved','joined','activated') LIMIT 30").fetchall():
        v=to_dict(r);cohort.append({**{k:v.get(k) for k in ['id','name','status','community_joined','creator_created']},'first_post':bool(v.get('first_post_url'))})
fixture={'/api/stats':stats_data,'/api/leads?limit=1500':leads,'/api/community/queue':cohort}
fixture.update({f'/api/leads/{x["id"]}':{**x,'events':[]} for x in leads})
fixture[f'/api/leads/{leads[0]["id"]}/draft']={'draft':draft_message(leads[0]),'method':'auditable-template','approval_required':True,'no_auto_send':True}
html=(ROOT/'static/index.html').read_text(encoding='utf-8')
css=(ROOT/'static/style.css').read_text(encoding='utf-8')
js=(ROOT/'static/app.js').read_text(encoding='utf-8')
html=html.replace('<link rel="stylesheet" href="/static/style.css">',f'<style>{css}</style>')
mock_js = r'''<script>
const FIXTURE = __JSON__;
window.fetch=async (url,options={}) => {
  let v=FIXTURE[url]||[];
  if (url.endsWith('/draft') && options.method === 'POST') {
    const id=url.split('/')[3];
    let r=FIXTURE['/api/leads?limit=1500'].find(x=>x.id===id);
    if(r){r.draft=v.draft;r.draft_method=v.method;r.draft_approved=false;}
  }
  return {ok:true,headers:{get:()=>'application/json'},json:async()=>v,text:async()=>JSON.stringify(v)};
};
</script>'''
mock=mock_js.replace('__JSON__',json.dumps(fixture,ensure_ascii=False))
html=html.replace('<script src="/static/app.js" defer></script>',mock+'<script>'+js+'</script>')
out=ROOT/'docs/previews';out.mkdir(parents=True,exist_ok=True)
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':960},device_scale_factor=1)
    errors=[]
    page.on('pageerror',lambda e: errors.append(str(e)))
    page.set_content(html,wait_until='load')
    page.wait_for_function("document.querySelector('#kpis .kpi b')?.textContent!=='—'")
    page.screenshot(path=str(out/'01_dashboard.png'),full_page=True)
    page.locator('#open-import').click()
    page.screenshot(path=str(out/'02_import.png'),full_page=True)
    page.locator('#close-modal').click()
    page.locator('.nav[data-view="leads"]').click()
    page.screenshot(path=str(out/'03_leads.png'),full_page=True)
    page.locator('#lead-rows [data-detail]').first.click()
    page.locator('#detail-modal').wait_for(state='visible',timeout=5000)
    page.screenshot(path=str(out/'04_evidence.png'),full_page=True)
    page.locator('#close-detail').click()
    page.locator('.nav[data-view="outreach"]').click()
    page.screenshot(path=str(out/'05_outreach.png'),full_page=True)
    page.locator('#generate').click()
    page.wait_for_timeout(350)
    page.wait_for_function("document.querySelector('#draft-text').value.length>20", timeout=3000)
    page.screenshot(path=str(out/'06_outreach_draft.png'),full_page=True)
    page.locator('.nav[data-view="community"]').click()
    page.screenshot(path=str(out/'07_cohort.png'),full_page=True)
    page.locator('.nav[data-view="plan"]').click()
    page.screenshot(path=str(out/'08_playbook.png'),full_page=True)
    application=(ROOT/'static/apply.html').read_text(encoding='utf-8').replace('<link rel="stylesheet" href="/static/style.css">',f'<style>{css}</style>')
    page.set_content(application,wait_until='load')
    page.screenshot(path=str(out/'09_application.png'),full_page=True)
    browser.close()
    if errors:raise AssertionError('Browser errors: '+str(errors))
    print('PASS: nine real-UI, synthetic-fixture screenshots rendered with zero JS runtime errors.')
    for f in sorted(out.glob('*.png')):print(f.relative_to(ROOT),f.stat().st_size)
