# Onely Creator Growth OS · 产品研发与增长笔试原型

> **演示原型，不是 Onely 官方产品。** 截至 2026-09-26，所有附带候选人、链接、漏斗数字均为 **100% 合成模拟数据**。没有联系真实候选人、投放广告、执行真实招募或开通 Onely 内部账号；不能将原型结果视为已经招募 100 人。

这是围绕 Onely 的「美国市场创作者运营者招募 → 证据化筛选 → 经审批触达 → 入驻 → 首次发布」业务流程开发的可运行 MVP。目标是展示产品能力与可测量的增长实验，而不是构造未经核实的实际招募成果。

## 1. 快速运行

**要求：Python 3.10+；不需要付费 API、Docker 或 n8n。**

```bash
# Windows PowerShell / macOS / Linux，在本仓库根目录执行
python -m venv .venv
# Windows: .\.venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python scripts/seed_demo.py
uvicorn app:app --host 127.0.0.1 --port 8000 --reload
```

浏览器打开：**http://127.0.0.1:8000**，公开申请表：**http://127.0.0.1:8000/apply**，API 自动文档：**http://127.0.0.1:8000/docs**。

项目附带 `data/onely.sqlite`：包含 53 条虚构身份，其中 52 条代表不同招募阶段，另有 1 条退出联系示例；**不要用真实人员替换后把 SQLite 数据库提交到 GitHub**。

如需重置纯模拟数据：

```bash
python scripts/seed_demo.py --reset
python -m pytest -q
```

演示导入：后台 Lead Intelligence → Import CSV → 选择 `data/sample_leads.csv`（13 行模拟样本：重复、Gmail 别名、错误邮箱均覆盖）。也可在主看板中查看已模拟的阶段和数据质量统计。

可选真正的 AI 文案重写：

```bash
pip install 'openai>=1.60,<3'
# Windows PowerShell:
$env:OPENAI_API_KEY="YOUR_OWN_KEY"
# macOS/Linux:
export OPENAI_API_KEY="YOUR_OWN_KEY"
```

后台 Outreach Studio 勾选真实模型后才会请求 API。`OPENAI_MODEL` 默认 `gpt-4.1-mini`（使用前确认账户支持及实际价格）。无 Key 走明确标注的**确定性模板**，不得称为真实模型调用。无论何种方式，文案均需人工批准，**本原型不会发送任何外部邮件或私信**。

## 2. 为什么不是普通 CRM

Onely 官网公开定位是覆盖 `Creator Identity → Content Production → Social Publishing → Fan Relationships → Subscriptions & E-commerce` 的创作者业务平台，目标受众包括 Creators、Agencies、Operators 和 Brands。对应的增长招募逻辑应该筛选**具备美国用户增长和转化经验的运营者**，而非只按粉丝量寻找网红。

本项目的专用能力：

- **美国市场资格的证据字段**：美国受众数据、公开投放案例、订阅/转化案例、每周内容产出和上线时间；保留链接与评分依据，没有证据就不给分。
- **两层身份识别**：专业邮箱归一化（仅 Gmail 合理折叠点号、+ 别名）+ 社媒主页 canonical URL 去重。跨来源重复合并，身份冲突进入人工处理，不根据姓名相似度强行合并。
- **运营式状态机**：`sourced → qualified → drafted → contacted → replied → interested → applied → approved → joined → activated`；拒绝和退订从漏斗退出，审计事件保留。进入 `joined` 必须满足 18+ 自我声明、美国市场案例经人工验证、申请人工批准与自愿加入社群。
- **两种文案生成**：无额度也可运行的事实约束模板；可选 API 重写。禁止虚构个人细节或收益承诺，商业邮件必须有真实发件身份、有效地址和退出方式。
- **自愿入驻表单 + 批量培训队列**：`/apply` 收集自愿提供的专业信息；D0/D1/D3/D7 的社群培训、角色创建、内容发布和留存节点。
- **漏斗 + 归因看板**：当前来源的一跳归因与保留的来源历史（多触点完整归因仍待实现）；显示去重、拒绝、退出和冲突数量。

## 3. 已实现 vs 未实现

| 模块 | 状态 | 证据 / 限制 |
|---|---|---|
| CSV 导入和 JSON 批量导入 | ✅ 已实现 | `/api/leads/import`, `/api/leads/upsert` |
| 精确邮箱/主页归一化、跨来源合并、冲突标记 | ✅ 已实现 | `core.py`; 不含昂贵的模糊身份推断 |
| 0–100 可解释筛选/ABC 分级 | ✅ 已实现 | `grade_row`; 提供的是待核查推荐而非自动资格认证 |
| 模板个性化英文触达文案 | ✅ 已实现 | `draft_message`; 不需要 Token |
| OpenAI 真实文案重写 | 🟡 已接入、未用真实额度实测 | 用户自备 API Key 和合法数据；失败返回错误，不伪装调用成功 |
| 人工审批、手动发送状态、退订屏蔽、事件审计 | ✅ 已实现 | 不连接实际发信服务 |
| 漏斗/渠道/KPI、本地 SQLite | ✅ 已实现 | 附带数据全为合成示例 |
| 公开自愿申请表、18+ 与同意勾选 | ✅ 已实现 | 演示环境未实现邮件 OTP、反机器人、身份核验 |
| Discord D0/D1/D3/D7 培训任务队列 | ✅ 任务预览 | 未连接 Discord API；无自动私信 |
| n8n 模拟入站导入模板 | 🟡 示例工作流 | `n8n/onely_manual_ingest.json`；需要在实际 n8n 环境验证节点兼容性 |
| Serper/YouTube 正式自动发现、Apollo 验证、CRM 生产同步 | ⏳ 待验证 | 依赖真实账号、API 授权、预算和平台条款 |
| Discord Bot 自动分配身份组、任务提醒和支持机器人 | ⏳ 待实现 | 需 Discord app、服务器管理权限、成员明确同意 |
| Onely 内部账户创建与真实首次发布事件回传 | ⏳ 待验证 | 需 Onely 官方 API 或运营后台协作；模拟链接不得计入真实成果 |
| 真实 100 名招募 / 收益数据 | ❌ 没有实测 | 只提供 3 天测算与执行框架 |

## 4. 招募增长方案摘要

**最终计数定义**：`Verified Join` = 一名唯一自然人，18+ 自我声明且通过实际入驻审核，有经人工核验的美国市场运营证明，完成 Onely 平台账户创建并加入自愿的创作者社群。仅填表、进入等候名单、收到邀请、仅加入 Discord 均**不得**计入 100 人目标。私测资格及 100 个可用名额需先由 Onely 确认。`Activation` 单独定义为生成第一个合规 AI 角色并发布一条真实可访问的社媒内容，跟踪至第 7 天。

**三路并行、高依赖条件的冲刺模型**（数字为假设，不是当前转换率）：

1. 伙伴推荐：联系 **30 家**具备美国市场案例的 UGC / Creator Agency 或运营负责人；假设 40% 成为可引荐伙伴，共 **12 家 × 4 个已审核入驻 = 48 人**。
2. 自愿报名：与获批准的创作者社群开展 2 场线上展示、发布招募信息；假设 **500 个合格页面访问 × 12% 申请 × 65% 通过并入驻 = 39 人**。
3. 人工审阅的合规直达：**700 个相关线索 × 85% 可联系 × 18% 正向回应 × 45% 申请 × 30% 最终入驻 ≈ 14 人**。
4. **合计约 101 个合格入驻，仅为积极情景**。此情景严重依赖预先存在的伙伴网络、跨时区即时审核、可确认的 Beta 名额和商业条款。冷启动条件不足时应诚实报告未达标原因及实际分渠道漏斗。

详见 [增长执行计划](docs/GROWTH_PLAN.md)、[产品需求与技术设计](docs/PRD.md)、[开源复用与许可证](docs/OPEN_SOURCE.md)、[演示录屏脚本](docs/DEMO_SCRIPT.md)。附带 [9 张真实前端合成数据截图](docs/previews/) 供快速预览。

## 5. 合规、隐私与局限

- 官方服务条款：Onely 18+；不允许色情露骨内容、侵权、虚假冒充；AI 角色应向粉丝明确 AI 属性，不通过误导或情绪依赖进行强迫销售。[Onely Terms](https://www.onely.cc/terms-of-service) ｜ [Onely Privacy](https://www.onely.cc/privacy-policy)
- 美国商业性质的邮件可能受 CAN-SPAM 约束（真实身份、真实主题、实体邮寄地址、简单退订与及时处理）；站内私信/Discord Bot 不做未获允许的群发。[FTC 官方说明](https://www.ftc.gov/business-guidance/resources/can-spam-act-compliance-guide-business) ｜ [Discord 开发者政策](https://support-dev.discord.com/hc/en-us/articles/8563934450327-Discord-Developer-Policy)
- 不通过非授权爬虫抓取 LinkedIn、Instagram、Reddit 联系方式；Reddit 商业数据 API 须另行申请许可。[Reddit 政策](https://support.reddithelp.com/hc/en-us/articles/14945211791892-Developer-Platform-Accessing-Reddit-Data)
- **当前只是本地演示：无用户登录鉴权、TLS、速率限制、CAPTCHA、真实邮箱验证、细粒度 RBAC 和数据删除 UI**。不得把本 Demo 直接公开部署并采集真实个人数据。上线前需专业合规审查及技术加固。
- **无真实 GitHub 仓库或公网演示地址**：此交付为完整可运行 ZIP，可由提交者自行建立 GitHub 仓库/部署。另有一个约 **4 分 46 秒的英文语音图解预览 MP4** 作为独立下载文件：其画面由真实前端与合成 API 测试数据生成，并非真人实时操作录屏；建议按 `docs/DEMO_SCRIPT.md` 在本地真实运行后另录一个操作演示，上传并填写真正公网 URL。不得虚构已公开的视频链接。

## 6. API 快览

`GET /api/health` · `GET /api/stats` · `GET /api/leads` · `POST /api/leads/import` (原始 UTF-8 CSV) · `POST /api/leads/upsert` (`{"leads":[...]}`) · `POST /api/applications` · `PATCH /api/leads/{id}/flags` · `PATCH /api/leads/{id}/status` · `POST /api/leads/{id}/draft` · `POST /api/leads/{id}/approve-draft` · `GET /api/community/queue`.

如需把 n8n 适配过来的候选线索导入，HTTP Request 发 `POST http://127.0.0.1:8000/api/leads/upsert`，JSON body 为 `{"leads": [{"name":"...", "email":"...", "platform":"TikTok", "profile_url":"https://...", "source":"partner"}]}`。可通过 `ONELY_INGEST_KEY` 和请求头 `x-ingest-key` 给此入口加简易访问控制，**但完整后台仍需生产级鉴权**。

## 7. 如何发布实际 GitHub 仓库和视频

在自己的 GitHub 创建空仓库 `onely-creator-growth-os` 后，进入本目录执行：

```bash
git init
git add .
git commit -m "Onely Creator Growth OS MVP"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/onely-creator-growth-os.git
git push -u origin main
```

用自己的用户名替换 `YOUR_USERNAME`；若 Git 尚未配置姓名、邮箱，先运行 `git config --global user.name ...` / `git config --global user.email ...`。创建前确认 `.env` 未包含真实密钥，SQLite 内仍只有虚构资料，且不要把 `onely_video_tmp` 等临时帧上传 GitHub。

视频可使用独立提供的合成数据预览 MP4 作为视觉说明，但最能证明运行方式的是根据 [演示脚本](docs/DEMO_SCRIPT.md) 亲自录制 3–5 分钟操作视频并上传到无需登录即可观看的链接。没有可访问链接时不得填写占位 URL。

**n8n 本地 Docker 说明**：模板中的 `host.docker.internal:8000` 仅为示例；Docker 容器能否访问取决于系统网络配置。若要使用容器与宿主机桥接，先将 FastAPI 绑定到合适的宿主机可访问地址，并在受信网络中设置 `ONELY_INGEST_KEY`，不要为了演示把无鉴权数据库公开到公网。
