"""Run with: uvicorn app:app --reload"""
from __future__ import annotations
import csv
import io
import json
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from core import (ROOT, connect, init_db, import_csv, import_rows, get_lead,
                  grade_row, set_status, set_flags, draft_message, event, now,
                  safe_csv_cell, stats, STAGES, OFF_RAMP)

@asynccontextmanager
async def lifespan(app):
    with connect() as con:init_db(con)
    yield

app=FastAPI(title='Onely Creator Growth OS',version='0.1.0',lifespan=lifespan)
app.mount('/static',StaticFiles(directory=str(ROOT/'static')),name='static')

class ImportJson(BaseModel):
    leads: list[dict[str,Any]] = Field(min_length=1,max_length=3000)

class StatusUpdate(BaseModel):
    status: str
    note: str = ''
    actor: str = 'reviewer'

class FlagUpdate(BaseModel):
    verified_us: bool|None = None
    application_reviewed: bool|None = None
    community_joined: bool|None = None
    creator_created: bool|None = None
    first_post_url: str|None = None
    owner: str|None = None
    notes: str|None = None

class DraftOptions(BaseModel):
    tone: str = 'friendly'
    channel: str = 'email'
    use_ai: bool = False

class Application(BaseModel):
    name: str = Field(min_length=2,max_length=150)
    email: str
    platform: str
    profile_url: str
    portfolio_url: str = ''
    us_case_url: str = ''
    us_audience_pct: float = 0
    conversion_case_url: str = ''
    conversion_note: str = ''
    posts_per_week: float = 0
    available_within_days: int = 7
    age_18_confirmed: bool
    consent_contact: bool
    niche: str = ''
    public_post_topic: str = ''
    source: str = 'self_apply'

@app.get('/',response_class=HTMLResponse)
def home():return (ROOT/'static'/'index.html').read_text(encoding='utf-8')

@app.get('/apply',response_class=HTMLResponse)
def public_apply():return (ROOT/'static'/'apply.html').read_text(encoding='utf-8')

@app.get('/api/health')
def health():return {'ok':True,'version':'0.1.0','mode':'synthetic-demo' if os.getenv('ONELY_DEMO','1')=='1' else 'local'}

@app.get('/api/stats')
def dashboard():
    with connect() as con:return stats(con)

@app.get('/api/leads')
def leads(status:str='',grade:str='',source:str='',q:str='',limit:int=500):
    with connect() as con:
        clauses=[];values=[]
        for field,value in (('status',status),('grade',grade),('source',source)):
            if value:clauses.append(f'{field}=?');values.append(value)
        if q: clauses.append('(name LIKE ? OR email LIKE ? OR niche LIKE ?)');values.extend(['%'+q+'%']*3)
        sql='SELECT * FROM leads'+(' WHERE '+' AND '.join(clauses) if clauses else '')+' ORDER BY score DESC,created_at DESC LIMIT ?'
        values.append(min(2000,max(1,limit)))
        from core import to_dict
        return [to_dict(r) for r in con.execute(sql,values).fetchall()]

@app.get('/api/leads/export')
def export_csv():
    with connect() as con: records=[dict(r) for r in con.execute('SELECT id,name,email,source,platform,profile_url,grade,score,status,next_followup,owner FROM leads ORDER BY score DESC')]
    output=io.StringIO();fields=list(records[0]) if records else ['id','name','email','status']
    writer=csv.DictWriter(output,fieldnames=fields);writer.writeheader()
    for r in records:writer.writerow({k:safe_csv_cell(v) for k,v in r.items()})
    return StreamingResponse(iter([output.getvalue()]),media_type='text/csv',headers={'Content-Disposition':'attachment; filename="onely_leads.csv"'})

@app.get('/api/leads/{lead_id}')
def lead_detail(lead_id:str):
    with connect() as con:
        try:
            r=get_lead(con,lead_id)
            r['events']=[dict(x) for x in con.execute('SELECT kind,stage,detail,at FROM events WHERE lead_id=? ORDER BY id DESC LIMIT 30',(lead_id,))]
            return r
        except LookupError:raise HTTPException(404,'Lead not found')

@app.post('/api/leads/import')
async def upload_csv(request:Request):
    body=await request.body()
    if len(body)>2_000_000:raise HTTPException(413,'CSV exceeds 2 MB')
    try: raw=body.decode('utf-8-sig')
    except UnicodeDecodeError:raise HTTPException(422,'CSV must be UTF-8')
    with connect() as con:
        try:return import_csv(con,raw)
        except csv.Error as e:raise HTTPException(422,str(e))

@app.post('/api/leads/upsert')
def ingest_json(payload:ImportJson,request:Request):
    expected=os.getenv('ONELY_INGEST_KEY','')
    if expected and request.headers.get('x-ingest-key')!=expected:
        raise HTTPException(401,'Missing/invalid ingest key')
    with connect() as con:return import_rows(con,payload.leads)

@app.post('/api/applications')
def submit_application(payload:Application):
    if not payload.age_18_confirmed:raise HTTPException(422,'Onely is 18+ only')
    if not payload.consent_contact:raise HTTPException(422,'Opt-in contact consent required')
    row=payload.model_dump()
    row['preferred_channel']='email';row['consent_contact']='yes';row['age_18_confirmed']='yes'
    with connect() as con:
        outcome=import_rows(con,[row])
        if outcome['suppressed'] or outcome['rejected'] or outcome['conflicts']:
            return JSONResponse(status_code=409,content={'message':'Application blocked by validation, suppression or conflicting identity','result':outcome})
        from core import normalize_email
        key=normalize_email(payload.email)
        found=con.execute('SELECT id,status FROM leads WHERE email_key=?',(key,)).fetchone()
        if not found:return JSONResponse(status_code=409,content={'message':'Unable to process; check duplicate, suppression or conflicting profile','result':outcome})
        # A form is a self-reported application, not evidence validation or acceptance.
        old=found['status'];lid=found['id']
        if old not in ('opted_out','declined') and old in STAGES and STAGES.index(old)<STAGES.index('applied'):
            con.execute('UPDATE leads SET status=?,updated_at=? WHERE id=?',('applied',now(),lid))
            event(con,lid,'self_application','applied','Form submission; pending human review')
            con.commit()
        return {'ok':True,'application_id':lid,'result':outcome,'review':'pending','message':'Application received; confirmation and review pending'}

@app.patch('/api/leads/{lead_id}/flags')
def update_flags(lead_id:str,payload:FlagUpdate):
    with connect() as con:
        try:return set_flags(con,lead_id,payload.model_dump(exclude_none=True))
        except LookupError:raise HTTPException(404,'Not found')

@app.patch('/api/leads/{lead_id}/status')
def update_status(lead_id:str,payload:StatusUpdate):
    with connect() as con:
        try:return set_status(con,lead_id,payload.status,payload.actor,payload.note)
        except LookupError:raise HTTPException(404,'Not found')
        except ValueError as e:raise HTTPException(409,str(e))

@app.post('/api/leads/{lead_id}/draft')
def make_draft(lead_id:str,options:DraftOptions):
    if options.channel not in ('email','discord','telegram','linkedin'):raise HTTPException(422,'Unsupported channel')
    if options.tone not in ('friendly','concise'):raise HTTPException(422,'Unknown tone')
    with connect() as con:
        try:r=get_lead(con,lead_id)
        except LookupError:raise HTTPException(404,'Not found')
        if r['status']=='opted_out':raise HTTPException(409,'Opted out')
        message=draft_message(r,options.tone,options.channel);method='auditable-template'
        if options.use_ai:
            if not os.getenv('OPENAI_API_KEY'):
                raise HTTPException(400,'OPENAI_API_KEY absent. Choose template mode or set your own key.')
            # No scraping and no claimed facts beyond input fields. No autonomous sends.
            from openai import OpenAI
            client=OpenAI(api_key=os.getenv('OPENAI_API_KEY'),timeout=12,max_retries=1)
            sys=('Rewrite this candidate outreach draft into friendly professional English, max 125 words. '
                 'Preserve factual statements and all safety disclosures. Never add claimed metrics, '
                 'income guarantees, inferred sensitive traits, or fictitious personal references. '
                 'This is a draft requiring human approval. Output text only.')
            try:
                response=client.responses.create(model=os.getenv('OPENAI_MODEL','gpt-4.1-mini'),
                    instructions=sys,input=message,max_output_tokens=240)
                if response.output_text.strip():message=response.output_text.strip();method='openai-reviewed-draft'
            except Exception as e:raise HTTPException(502,f'AI unavailable ({type(e).__name__}); template fallback available')
        con.execute('UPDATE leads SET draft=?,draft_method=?,draft_approved=0,updated_at=? WHERE id=?',
                    (message,method,now(),lead_id))
        event(con,lead_id,'drafted',detail=f'{method}; {options.channel}; human review required')
        if r['status']=='qualified':
            con.execute('UPDATE leads SET status=? WHERE id=?',('drafted',lead_id))
            event(con,lead_id,'status','drafted','qualified → drafted')
        con.commit()
        return {'draft':message,'method':method,'approval_required':True,'no_auto_send':True}

@app.post('/api/leads/{lead_id}/approve-draft')
def approve_draft(lead_id:str):
    with connect() as con:
        try:r=get_lead(con,lead_id)
        except LookupError:raise HTTPException(404,'Not found')
        if not r['draft']:raise HTTPException(409,'Generate draft first')
        if r['status']=='opted_out':raise HTTPException(409,'Opted out')
        con.execute('UPDATE leads SET draft_approved=1,updated_at=? WHERE id=?',(now(),lead_id))
        event(con,lead_id,'draft_approved',detail='Human-approved; external sending remains manual')
        con.commit()
        return {'ok':True,'approved':True,'sending':'manual_only'}

@app.get('/api/community/queue')
def community_queue():
    with connect() as con:
        rows=con.execute("SELECT id,name,email,source,status,community_joined,creator_created,first_post_url FROM leads WHERE status IN ('applied','approved','joined','activated') ORDER BY updated_at DESC").fetchall()
        def checklist(row):
            r=dict(row)
            return {'id':r['id'],'name':r['name'],'status':r['status'],
                    'D0': ['Welcome + 18+ & eligibility check','Choose creator persona','Community rules & disclosure'],
                    'D1': ['Build first AI character','Publish first 3-post content pack'],
                    'D3': ['Publish US-timezone test post','Review visits, CTR, profile clicks'],
                    'D7': ['Review repeat posting and opt-in cohort retention'],
                    'community_joined':bool(r['community_joined']),
                    'creator_created':bool(r['creator_created']),
                    'first_post':bool(r['first_post_url'])}
        return [checklist(r) for r in rows]
