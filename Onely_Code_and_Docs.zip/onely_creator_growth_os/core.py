"""Onely Growth OS: auditable, rule-based CRM engine for opt-in creator recruitment."""
from __future__ import annotations
import csv
import io
import json
import os
import re
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse, unquote

ROOT = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv('ONELY_DB_PATH', str(ROOT / 'data' / 'onely.sqlite')))
STAGES = ['sourced', 'qualified', 'drafted', 'contacted', 'replied', 'interested', 'applied', 'approved', 'joined', 'activated']
OFF_RAMP = ['declined', 'opted_out']
FIELDS = ['name','email','platform','profile_url','source','portfolio_url','us_case_url',
          'us_audience_pct','conversion_case_url','conversion_note','posts_per_week',
          'available_within_days','age_18_confirmed','consent_contact','public_post_topic',
          'niche','preferred_channel','notes']
ALIASES = {'full_name':'name','contact_email':'email','social_platform':'platform',
           'social_url':'profile_url','channel':'platform','source_channel':'source',
           'us_market_proof':'us_case_url','paid_campaign_url':'conversion_case_url'}


def now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def clean_text(value, limit=500):
    if value is None: return ''
    return re.sub(r'[\x00-\x1f\x7f]', ' ', str(value)).strip()[:limit]


def truth(value):
    return str(value).strip().lower() in {'1','true','yes','y','是','checked'}


def numeric(value, default=0):
    try: return max(0.0, float(str(value or '').replace('%','').replace(',','')))
    except (ValueError,TypeError): return float(default)


def normalize_email(value):
    e = clean_text(value, 255).lower()
    if not e: return ''
    if not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]{2,}',e): raise ValueError('Invalid email')
    local, domain = e.rsplit('@', 1)
    # Gmail's documented consumer alias behavior; never strip + for other domains.
    if domain in ('gmail.com', 'googlemail.com'):
        local = local.split('+')[0].replace('.', '')
        domain = 'gmail.com'
    return f'{local}@{domain}'


def normalize_profile(value, platform=''):
    v = clean_text(value, 400)
    if not v: return ''
    if v.startswith('@') and platform:
        return f'{clean_text(platform,50).lower()}:{v[1:].lower()}'
    if not re.match(r'^https?://',v,flags=re.I): v='https://'+v
    p=urlparse(v)
    if not p.netloc: return ''
    host=p.netloc.lower().removeprefix('www.').removeprefix('m.')
    path=unquote(p.path).rstrip('/').lower()
    if host in {'x.com','twitter.com'}: host='x.com'
    if host in {'youtube.com','youtu.be'}: host='youtube.com'
    if host=='instagram.com' and path.startswith('/'): path=path.split('/')[1] if len(path.split('/'))>1 else ''
    return f'{host}:{path.lstrip("/")}' if path else host


def grade_row(r):
    """No sensitive traits, follower count or AI guesses. Missing proof = zero points."""
    evidence=[]; score=0
    us_url=clean_text(r.get('us_case_url'))
    us_pct=numeric(r.get('us_audience_pct'))
    if us_url.startswith(('https://','http://')):
        score+=25; evidence.append('US campaign/source link +25')
    elif us_pct>0:
        score+=10; evidence.append('US audience claim, unverified +10')
    if us_pct>=40 and us_url: score+=5; evidence.append('US audience ≥40%, source supplied +5')
    platforms={x.strip().lower() for x in re.split(r'[,;/|]',str(r.get('platform') or '')) if x.strip()}
    platform_score=min(25,sum(8 if p in {'tiktok','instagram','youtube'} else 5 for p in platforms))
    score+=platform_score
    if platform_score:evidence.append(f'relevant social platforms +{platform_score}')
    if clean_text(r.get('conversion_case_url')).startswith(('https://','http://')):
        score+=20; evidence.append('conversion case URL +20')
    elif clean_text(r.get('conversion_note')):
        score+=8; evidence.append('unverified conversion narrative +8')
    posts=numeric(r.get('posts_per_week'))
    execution=12 if posts>=4 else 8 if posts>=2 else 4 if posts>=1 else 0
    if clean_text(r.get('portfolio_url')).startswith(('https://','http://')): execution+=3
    score+=execution
    if execution:evidence.append(f'publishing & portfolio +{execution}')
    days=numeric(r.get('available_within_days'),default=999)
    if 0<days<=3:score+=10; evidence.append('available within 72h +10')
    elif 3<days<=7:score+=5; evidence.append('available within 7d +5')
    # Evidence is a requirement for A even if high numeric score.
    grade='A' if score>=80 and us_url else 'B' if score>=60 else 'C'
    if not us_url: evidence.append('US-market evidence needs review')
    return score, grade, evidence


def connect(path=None):
    p=Path(path or DB_PATH)
    p.parent.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(str(p))
    con.row_factory=sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    con.execute('PRAGMA busy_timeout=5000')
    return con


def init_db(con):
    con.executescript('''
    CREATE TABLE IF NOT EXISTS leads(
      id TEXT PRIMARY KEY, name TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '',
      email_key TEXT, platform TEXT DEFAULT '', profile_url TEXT DEFAULT '', profile_key TEXT,
      source TEXT DEFAULT '', source_history TEXT DEFAULT '[]', profile_history TEXT DEFAULT '[]',
      portfolio_url TEXT DEFAULT '', us_case_url TEXT DEFAULT '', us_audience_pct REAL DEFAULT 0,
      conversion_case_url TEXT DEFAULT '', conversion_note TEXT DEFAULT '', posts_per_week REAL DEFAULT 0,
      available_within_days REAL DEFAULT 999, age_18_confirmed INTEGER DEFAULT 0,
      consent_contact INTEGER DEFAULT 0, public_post_topic TEXT DEFAULT '', niche TEXT DEFAULT '',
      preferred_channel TEXT DEFAULT 'email', notes TEXT DEFAULT '', score INTEGER DEFAULT 0,
      grade TEXT DEFAULT 'C', evidence TEXT DEFAULT '[]', status TEXT DEFAULT 'sourced',
      draft TEXT DEFAULT '', draft_method TEXT DEFAULT '', draft_approved INTEGER DEFAULT 0,
      verified_us INTEGER DEFAULT 0, application_reviewed INTEGER DEFAULT 0,
      community_joined INTEGER DEFAULT 0, creator_created INTEGER DEFAULT 0,
      first_post_url TEXT DEFAULT '', owner TEXT DEFAULT '',
      next_followup TEXT DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_lead_email ON leads(email_key) WHERE email_key IS NOT NULL;
    CREATE UNIQUE INDEX IF NOT EXISTS idx_lead_profile ON leads(profile_key) WHERE profile_key IS NOT NULL;
    CREATE TABLE IF NOT EXISTS events(
      id INTEGER PRIMARY KEY AUTOINCREMENT, lead_id TEXT NOT NULL REFERENCES leads(id),
      kind TEXT NOT NULL, stage TEXT DEFAULT '', detail TEXT DEFAULT '', at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS suppression(
      key TEXT PRIMARY KEY, reason TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS import_runs(
      id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT, total INTEGER, inserted INTEGER,
      merged INTEGER, rejected INTEGER, suppressed INTEGER, conflicts INTEGER);
    ''')
    con.commit()


def event(con, lead_id, kind, stage='', detail=''):
    con.execute('INSERT INTO events(lead_id,kind,stage,detail,at) VALUES(?,?,?,?,?)',
                (lead_id,kind,stage,clean_text(detail,800),now()))


def to_dict(row):
    r=dict(row)
    for field in ('source_history','profile_history','evidence'):
        r[field]=json.loads(r[field] or '[]')
    for flag in ('age_18_confirmed','consent_contact','draft_approved','verified_us','application_reviewed','community_joined','creator_created'):
        r[flag]=bool(r[flag])
    return r


def upsert(con, raw, actor='csv_import', log=True):
    data={ALIASES.get(k.strip().lower(),k.strip().lower()):v for k,v in raw.items() if k}
    r={k: clean_text(data.get(k),1200 if k in {'notes','conversion_note'} else 400) for k in FIELDS}
    r['source']=r['source'] or 'direct'; r['preferred_channel']=r['preferred_channel'] or 'email'
    try: ek=normalize_email(r['email']) or None
    except ValueError:return ('rejected','Invalid email')
    pk=normalize_profile(r['profile_url'],r['platform']) or None
    if not ek and not pk: return ('rejected','Missing email and social profile')
    for key in (ek,pk):
        if key and con.execute('SELECT 1 FROM suppression WHERE key=?',(key,)).fetchone():
            return ('suppressed','Suppression list match')
    email_match=con.execute('SELECT * FROM leads WHERE email_key=?',(ek,)).fetchone() if ek else None
    profile_match=con.execute('SELECT * FROM leads WHERE profile_key=?',(pk,)).fetchone() if pk else None
    if email_match and profile_match and email_match['id']!=profile_match['id']:
        return ('conflicts','Email and social profile belong to two different records')
    match=email_match or profile_match
    r['us_audience_pct']=numeric(r['us_audience_pct']);r['posts_per_week']=numeric(r['posts_per_week'])
    r['available_within_days']=numeric(r['available_within_days'],default=999)
    r['age_18_confirmed']=int(truth(r['age_18_confirmed']))
    r['consent_contact']=int(truth(r['consent_contact']))
    if match:
        if ek and match['email_key'] and ek!=match['email_key']:
            return ('conflicts','Same profile has conflicting emails; manual review required')
        preserved=to_dict(match)
        for key in FIELDS:
            v=r[key]
            if key in ('age_18_confirmed','consent_contact'):
                preserved[key]=int(bool(v) or preserved[key])
            elif key in ('posts_per_week','us_audience_pct'):
                preserved[key]=max(float(preserved[key] or 0),float(v or 0))
            elif key=='available_within_days':
                preserved[key]=min(float(preserved[key] or 999),float(v or 999))
            elif v and (not preserved.get(key) or key in ('notes',)):
                preserved[key]=v if key!='notes' else (str(preserved[key])+' | '+str(v)).strip(' | ')[:1200]
        source_history=sorted(set(preserved['source_history']+[r['source']]))
        profiles=sorted(set(preserved['profile_history']+([r['profile_url']] if r['profile_url'] else [])))
        if pk and not match['profile_key']:preserved['profile_key']=pk
        if ek and not match['email_key']:preserved['email_key']=ek
        score,grade,evidence=grade_row(preserved)
        cols=FIELDS+['email_key','profile_key','score','grade','evidence','source_history','profile_history','updated_at']
        values=[preserved.get(k) for k in FIELDS]+[preserved.get('email_key'),preserved.get('profile_key'),score,grade,
                 json.dumps(evidence),json.dumps(source_history),json.dumps(profiles),now()]
        con.execute('UPDATE leads SET '+','.join(f'{k}=?' for k in cols)+' WHERE id=?',values+[match['id']])
        if log:event(con,match['id'],'merged',match['status'],f'New source: {r["source"]}')
        return ('merged',match['id'])
    lid=str(uuid.uuid4())
    score,grade,evidence=grade_row(r)
    cols=FIELDS+['id','email_key','profile_key','source_history','profile_history','score','grade','evidence','status','created_at','updated_at']
    values=[r[k] for k in FIELDS]+[lid,ek,pk,json.dumps([r['source']]),json.dumps([r['profile_url']] if r['profile_url'] else []),
                              score,grade,json.dumps(evidence),'sourced',now(),now()]
    con.execute('INSERT INTO leads ('+','.join(cols)+') VALUES ('+','.join('?'*len(cols))+')',values)
    if log:event(con,lid,'imported','sourced',f'Source {r["source"]}; score {score}')
    return ('inserted',lid)


def import_rows(con,rows):
    tally={x:0 for x in ('total','inserted','merged','rejected','suppressed','conflicts')}
    for row in rows:
        if not isinstance(row,dict):continue
        tally['total']+=1
        try:
            with con: outcome,_=upsert(con,row)
            tally[outcome]+=1
        except sqlite3.IntegrityError:
            tally['conflicts']+=1
    con.execute('INSERT INTO import_runs(at,total,inserted,merged,rejected,suppressed,conflicts) VALUES(?,?,?,?,?,?,?)',
                (now(),*(tally[k] for k in ('total','inserted','merged','rejected','suppressed','conflicts'))))
    con.commit()
    return tally


def import_csv(con,raw):
    rows=list(csv.DictReader(io.StringIO(raw.lstrip('\ufeff'))))
    if not rows:return {k:0 for k in ('total','inserted','merged','rejected','suppressed','conflicts')}
    return import_rows(con,rows)


def get_lead(con,lead_id):
    row=con.execute('SELECT * FROM leads WHERE id=?',(lead_id,)).fetchone()
    if not row:raise LookupError('Lead not found')
    return to_dict(row)


def set_flags(con,lead_id,flags):
    allowed={'verified_us','application_reviewed','community_joined','creator_created','first_post_url','owner','notes'}
    updates={k:(int(bool(v)) if k in {'verified_us','application_reviewed','community_joined','creator_created'} else clean_text(v,500))
             for k,v in flags.items() if k in allowed}
    if not updates:return get_lead(con,lead_id)
    con.execute('UPDATE leads SET '+','.join(f'{k}=?' for k in updates)+',updated_at=? WHERE id=?',
                list(updates.values())+[now(),lead_id])
    event(con,lead_id,'verified',detail=','.join(updates))
    con.commit()
    return get_lead(con,lead_id)


def set_status(con,lead_id,target,actor='reviewer',note=''):
    r=get_lead(con,lead_id);old=r['status']
    if target not in STAGES+OFF_RAMP:raise ValueError('Unknown pipeline status')
    if old=='opted_out' and target!='opted_out':raise ValueError('Opt-out cannot be reversed in this demo')
    if target=='opted_out':
        for key in (r['email_key'],r['profile_key']):
            if key:con.execute('INSERT OR IGNORE INTO suppression VALUES(?,?,?)',(key,'opted_out',now()))
    elif target not in OFF_RAMP:
        if old in OFF_RAMP:raise ValueError('Inactive lead cannot advance')
        if STAGES.index(target)>STAGES.index(old)+1:raise ValueError('Move through one stage at a time')
        if STAGES.index(target)<STAGES.index(old):raise ValueError('Backward movement requires separate human review')
        if target=='contacted':
            if not r['draft_approved']:raise ValueError('Approve the outreach draft first')
            if not r['email'] and not r['profile_url']:raise ValueError('Missing contact')
            if r['preferred_channel'].lower() in ('discord','telegram') and not r['consent_contact']:
                raise ValueError('Opt-in required for Discord/Telegram direct outreach')
        if target=='approved' and not r['application_reviewed']:
            raise ValueError('Application needs human review')
        if target=='joined' and not (r['age_18_confirmed'] and r['verified_us'] and r['community_joined'] and r['application_reviewed']):
            raise ValueError('Join gate: 18+ declaration, verified US case, human review, community membership')
        if target=='activated' and not (r['creator_created'] and r['first_post_url'].startswith(('https://','http://'))):
            raise ValueError('Activation gate: creator created and first public post URL')
    con.execute('UPDATE leads SET status=?,updated_at=? WHERE id=?',(target,now(),lead_id))
    event(con,lead_id,'status',target,f'{old} → {target}; {actor}: {note}')
    con.commit()
    return get_lead(con,lead_id)


def draft_message(r,tone='friendly',channel='email'):
    """Fact-only template fallback. Human must review before contacting anyone."""
    if r['status']=='opted_out':raise ValueError('Opted-out contacts cannot be drafted')
    first=clean_text(r['name'].split(' ')[0] if r['name'] else 'there',60)
    genre=clean_text(r.get('niche') or 'creator growth',80)
    evidence=clean_text(r.get('public_post_topic'),90)
    specific=f'I came across your public work on {evidence}.' if evidence else f'Your experience in {genre} caught my attention.'
    intro=(f'Hi {first}, {specific} '
           'I’m reaching out about an opt-in opportunity for operators who understand US social audiences. '
           'Onely is building a creator business platform spanning AI-assisted content, audience growth, and fan subscriptions. '
           'Would you be open to a short intro and beta onboarding details? '
           'I can share the role, eligibility, platform costs and any confirmed commercial terms before you decide. '
           'No guaranteed earnings are implied. If this is not relevant, reply "no" and I won’t follow up.')
    if tone=='concise':intro=(f'Hi {first} — {specific} Onely is inviting US-market social operators to beta-test its '
                              'AI-assisted creator business platform. Open to details? No earnings promises; reply "no" to opt out.')
    if channel=='email':
        intro='Subject: Onely creator-operator beta invitation\n\n'+intro+'\n\n[Add your real sender identity and business postal address before sending.]'
    return intro


def stats(con):
    items=[dict(x) for x in con.execute('SELECT status,source,grade,score FROM leads')]
    active=[x for x in items if x['status'] not in OFF_RAMP]
    stage={x:sum(1 for r in active if r['status'] in STAGES and STAGES.index(r['status'])>=STAGES.index(x)) for x in STAGES}
    sources={}
    for x in items:
        group=sources.setdefault(x['source'],{'total':0,'qualified':0,'joined':0,'activated':0})
        group['total']+=1
        group['qualified']+=int(x['grade'] in ('A','B'))
        group['joined']+=int(x['status'] in ('joined','activated'))
        group['activated']+=int(x['status']=='activated')
    runs=con.execute('SELECT COALESCE(SUM(merged),0) merged,COALESCE(SUM(rejected),0) rejected,COALESCE(SUM(suppressed),0) suppressed,COALESCE(SUM(conflicts),0) conflicts FROM import_runs').fetchone()
    qualified=sum(1 for x in items if x['grade'] in ('A','B') and x['status'] not in OFF_RAMP)
    return {'total':len(items),'qualified':qualified,'grades':{g:sum(x['grade']==g for x in items) for g in ['A','B','C']},
            'pipeline':stage,'opted_out':sum(x['status']=='opted_out' for x in items),
            'sources':sources,'import_quality':dict(runs),
            'contact_rate':round(100*stage['contacted']/qualified,1) if qualified else 0,
            'reply_rate':round(100*stage['replied']/stage['contacted'],1) if stage['contacted'] else 0,
            'join_rate':round(100*stage['joined']/stage['applied'],1) if stage['applied'] else 0,
            'activation_rate':round(100*stage['activated']/stage['joined'],1) if stage['joined'] else 0}


def safe_csv_cell(value):
    s=str(value or '')
    return "'"+s if s.startswith(('=','+','-','@','\t','\r')) else s
