# PRD + Technical Design

## 1. 用户故事

Growth Owner 在 72h 内需要知道哪些来源带来真的美国市场运营者；Reviewer 需要看到候选人的公开专业证明、识别邮箱/平台重复和冲突、审批接触方式与 AI 草稿；Community Manager 需要在 D0/D1/D3/D7 管理已批准的成员，发现缺失动作，而不是给所有人重复手动发流程。

## 2. P0 需求与验收

| ID | 需求 | 验收方法 |
|---|---|---|
| P0-01 | 线索来源批量导入 | CSV JSON 两种 API；缺邮箱和平台主页拒绝；同邮箱再次导入数量不增加 |
| P0-02 | 不同来源身份去重 | Gmail 合规别名归一，平台 canonical 归一，合并来源历史；同主页矛盾邮箱进入 conflicts |
| P0-03 | 可解释筛选 | 30/25/20/15/10 五项评分；缺证据不可加分；返回 evidence 列表；A/B/C 可过滤 |
| P0-04 | 受控文案与跟进 | 模板生成，AI 可选；没有可见事实则泛化；必须审批才能把联系状态标记为已发送；有事件历史 |
| P0-05 | 资格型入驻漏斗 | 自愿报名 + 18+ 声明 + 联系同意；joined 状态需真实人工核验与确认社群成员；激活需要角色+真实贴文 URL |
| P0-06 | 来源表现与成本信号 | 每来源 raw/qualified/joined/activated；已联系/回复、申请/加入和加入/激活比率；拒绝、重复、退订、冲突 |
| P0-07 | 批量培训准备 | D0/D1/D3/D7 检查单、角色分流示意和人工支持入口；机器人不可发未获授权 DM |

## 3. 技术栈与职责

```
CSV/Partner referral/Opt-in form/n8n import
  -> FastAPI /api/leads/import | /api/leads/upsert | /api/applications
  -> Pydantic basic schema and Python canonical normalization
  -> SQLite leads + suppression + events + import_runs
  -> Deterministic fit score and review evidence
  -> Optional OpenAI draft rewrite / safe default template
  -> Human approve gate, manual sending
  -> Audit status transitions and joined/activated verification gates
  -> Source/funnel stats + D0/D1/D3/D7 community checklist
```

主仓库故意不启动 n8n、Twenty 或 Apollo 依赖。此选择用一小时可验收的独立可运行 demo 换取未来用官方 API 升级的余地。FastAPI/OpenAPI 是当前真实接口契约，n8n 可以调用 HTTP 接口，本地模拟 workflow 可从 `n8n/onely_manual_ingest.json` 导入；Twenty 后续走其 API。模拟外部 UGC 案例链接均为 `.example`，不可用于实际背景核查。

SQLite 表：`leads` 唯一邮箱/主页（非 null）、原始证据及文本、分级、状态、审核标志、拟写草稿、拥有者；`events` 所有变更审计；`suppression` 永久退出联系键；`import_runs` 导入质量记录。原型还没有多用户并发与权限控制，生产迁移到 PostgreSQL 并使用 worker 处理后台任务。

## 4. P1 / P2 后续路线（没有实现，不得演示为现成）

**P1**：官方合规来源 API、邮箱可达性验证、RBAC 与操作日志查询、TSV/XLSX 文件清理、工作流任务调度、每个审核者的操作负载和 SLA、可撤销同意/数据删除、从 Onely Beta 后台回收实际注册事件、Discord OAuth + 服务器成员确认。

**P2**：使用 Upstream MIT n8n Recruitment Pipeline 配置美国运营者查询词和审核权重，通过 HTTP /api/leads/upsert 导入；付费 Apollo Enrichment 限于需验证的专业联系信息，未批准的自动采集关闭；与 Twenty CRM 自定义对象 `CreatorOperatorLead` 和自建 Onely 字段双向同步；Discord 成员同意后由 Bot 设角色并在公共线程提醒；Telegram 自愿订阅仅同步活动公告；Webhook 事件进入实时 cohort 分析和 D7 留存归因。

## 5. 最低安全与可靠性

目前仅用于 localhost + 合成数据。生产前必须增加：HTTP Basic/OIDC/SSO、不同角色权限、网络层 HTTPS、CSRF、rate limiting、队列重试、事务幂等键、防式量数据注入、来源采集授权记录、隐私告知及数据删除、密钥保管、双向解绑 Discord、发信域名 SPF/DKIM/DMARC，以及经审批的合法退订流程。不得将 README 给出的本地 demo 直接上线处理真实个人信息。

### AI guardrails

AI 不为缺失的美国受众指标补数；不根据候选人的年龄外观、种族、性别等推断运营能力；不假冒个人熟人、不编造收益与合作结果；上下文只包含公开、获准使用的业务字段；输出由人工复核；保存生成模式与版本以供复盘。更复杂的生产方案可用约束 JSON Schema 和字段级来源引用为每句文案留证据链。
