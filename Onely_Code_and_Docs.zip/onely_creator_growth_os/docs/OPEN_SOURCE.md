# 开源/现成代码调查与复用策略

本项目使用成熟的 FastAPI、Pydantic、SQLite、浏览器原生能力作为可立即运行的核心。**没有实际克隆或复制以下外部仓库的任何代码**，因此此 ZIP 不属于其 fork，也没有将开源 n8n 模板冒充已验证集成。以下是调研到、计划以 API/工作流方式对接的上游项目；`n8n/onely_manual_ingest.json` 是本项目自行写的最小示例，需由提交者在目标 n8n 版本上再次验证。

| 工具/仓库 | 具体复用价值 | 许可证 / 决策 |
|---|---|---|
| [Shravan / AI Recruiting Sourcing Pipeline](https://github.com/shravangithub/ai-recruiting-sourcing-pipeline) | n8n 已实现 JD->布尔 X-Ray 搜索->Serper->LLM ranking->Apollo enrichment->Google Sheets->人工批准触达，并自带 workflow JSON | MIT，可 fork/修改，须保留 LICENSE；改造其 JD 与评分为美国运营者条件，用本项目 `/api/leads/upsert` 替换 CRM 写入；先禁用其自动发送节点，审核合规后再联通 |
| [FranciscoContreras / twenty-app-intake](https://github.com/FranciscoContreras/twenty-app-intake) | Webhook 字段归一、CRM lead 去重/审计，自适应导入 | MIT；可以在使用 Twenty 时用 API 代替手工自建更成熟的入站链路 |
| [twentyhq/twenty](https://github.com/twentyhq/twenty) | 完整 CRM 的自定义对象、用户权限、Kanban、Workflow 与 API | 主要开源部分为 AGPLv3，具有应用例外/商业部分；本原型只计划通过 API 使用，未复制代码，也不承担耗时的整套部署 |
| [n8n](https://github.com/n8n-io/n8n) | 自动化编排工具和 HTTP 请求、表单、邮件与 Discord 集成 | source-available/fair-code Sustainable Use License，不是 OSI 式开源许可证；作为合规内用独立服务，商业白标/嵌入需检查许可 |
| [FastAPI](https://github.com/fastapi/fastapi) / [Pydantic](https://github.com/pydantic/pydantic) | REST API / 入参校验与 Swagger 文档 | MIT；代码仓库的实际使用依赖 |
| SQLite | 轻量持久化和约束、事务 | 公共领域；适合无 Token 的本地原型 |

**复用的明确技术动作**：
1. 现在可演示的是 `core.py` 和 `app.py`。它们的输入 schema 已和 n8n HTTP Request 普通 JSON payload 对齐。
2. 下一阶段在具有网络和 n8n 权限的环境中，`git clone https://github.com/shravangithub/ai-recruiting-sourcing-pipeline.git`，保留上游 MIT LICENSE；导入其真实 `ai-recruiting-pipeline.template.json`，将 source queries 变更为 UGC agency / US audience / growth operator，用 Onely 评分配置替换通用招聘条件。删除/禁用其未经批准的自动触达节点。
3. 用 n8n HTTP Request 将核实的输出 POST 到本项目 `/api/leads/upsert`，而不是重复实现在线搜索及 Apollo。当前自带 `n8n/onely_manual_ingest.json` 用虚构一条样本模拟这个桥接路径。
4. 若 Onely 生产部署已有 CRM，就替换本地 SQLite 接口的 repository 层为 Twenty API/PostgreSQL，不再造完整 CRM 管理平台。

不采用某些无 LICENSE 的公开 GitHub 代码：网页可浏览不等于代码可合法复制。也不采用未得到许可的 Instagram/LinkedIn 大规模爬虫：技术可行不代表平台与隐私合规。
