# 4 分钟演示视频脚本（实操录屏指南）

> 必须在真实运行本仓库后录屏。此 ZIP 提供完整代码、截图与脚本；不会编造公网录屏 URL。推荐 OBS Studio、Windows 录屏工具，或 Zoom 本地录制。视频 16:9、720p/1080p、时长 3–5 分钟，完成后上传 YouTube Unlisted / 可公开访问的网盘并把**真实链接**放进提交邮件。

**录屏前**：`python scripts/seed_demo.py --reset`，`uvicorn app:app --reload`，打开 `http://127.0.0.1:8000`，确保 Chrome 标签未泄露密钥或真实个人信息，显示网站顶部/左侧的 `Demo mode`。

| 时间 | 屏幕动作 | 口播关键句 |
|---|---|---|
| 0:00–0:25 | 打开 Overview；展示 100 target 与所有合成数据明确标签 | “Onely 招募的不是单纯有粉丝的人，而是能面向美国市场运营并产生付费转化的 operator。100 人是三天目标，当前数字只是用于验证系统的模拟数据。” |
| 0:25–1:10 | 点击 Lead Intelligence → Import CSV → 上传 `data/sample_leads.csv`；展示新插入/合并/拒绝数；刷新看板 | “系统把 CSV 与 n8n/自愿报名汇入同一数据模型。相同邮箱和社媒主页不会重复计人。字段矛盾交给人工审核；退订记录阻止二次触达。” |
| 1:10–1:45 | 进入一位 A 类 Operator 详情，展示 Evidence 与 Score；人工验证按钮、状态变更 | “评分拆解为美国市场证据 30、平台能力 25、转化案例 20、执行 15、上线 10。所有分数都保留依据，但入驻需要独立的人类核查。” |
| 1:45–2:25 | Outreach Studio → 选择一位在 Qualified 阶段的 operator → Generate → 审阅 → Approve Draft；不要真正发送 | “无 Token 也能使用可解释模板；有真实 API Key 可选 LLM 重写。模型不能虚构收益、案例。文案必须审批，并严格分离‘生成’与‘已经联系’。” |
| 2:25–2:55 | Public application 打开 → 展示社媒主页/案例/18+ 和同意框（可用 example.com 虚构地址提交） | “对主动报名的候选人，单页完成结构化信息收集，后台自动与已有线索去重，但不会自动标记已通过审核。” |
| 2:55–3:25 | Cohort operations → D0/D1/D3/D7 → 公共频道/人工升级 | “入驻后不是群发链接就结束；按运营角色分班、公开材料自助学习，用首次角色创建和首次公开内容验证有效激活。” |
| 3:25–4:00 | Growth playbook → 48/39/14 三渠道模型和底部条件提醒 → Overview | “我们以合作伙伴推荐、社区自愿报名和审核后外联三路并行；总计 101 是乐观假设，真实数据必须分别统计。最大的业务风险是预热伙伴和真实 Beta 名额，不会把报名等同于加入。” |

**视频结尾用一页简短标注**：Implemented: local CRM ingestion, dedupe, scoring, templates/AI hook, human approval, status analytics, voluntary application, cohort checklist. Pending validation: source API permissions, actual mailing, Discord Bot, Onely account events, real 3-day conversion and 7-day retention.

**终局交付**：真实 GitHub repo URL + README + 演示视频实际分享 URL。当前离线 ZIP 自带完整代码可作为仓库初始版本；没有联网发布功能，提交前需要本人上传。

**独立视频预览说明（本次附带）**：系统自动生成约 4 分 46 秒、英文配音的九屏图解视频，涵盖看板、导入、筛选、人工审核、触达文案、公开表单、分班与三天模型。此视频使用真正的前端代码与合成 API fixtures 渲染后的截图，**不是**浏览器真人实时操作录屏，也不等于真实招募结果。视频文件在 ZIP 外另行下载；如可用真人操作录屏，优先提交真人操作版。
