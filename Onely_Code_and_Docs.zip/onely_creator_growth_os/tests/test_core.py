import csv
import io
import json
import pytest
from core import connect,init_db,import_csv,import_rows,normalize_email,normalize_profile,grade_row,set_flags,set_status,draft_message,stats,get_lead

@pytest.fixture
def db(tmp_path):
    with connect(tmp_path/'test.sqlite') as con:
        init_db(con)
        yield con

@pytest.fixture
def valid():
    return {'name':'Synthetic Applicant','email':'Synthetic.Test+first@gmail.com',
       'platform':'TikTok, Instagram, YouTube','profile_url':'https://Instagram.com/Test.Person/?hl=en',
       'source':'community_optin','us_case_url':'https://example.com/us-case',
       'us_audience_pct':'62','conversion_case_url':'https://example.com/conversion',
       'portfolio_url':'https://example.com/portfolio','posts_per_week':'5','available_within_days':'2',
       'age_18_confirmed':'yes','consent_contact':'yes','niche':'lifestyle storytelling'}

def test_normalization():
    assert normalize_email('  Synthetic.Test+first@Gmail.com ')=='synthetictest@gmail.com'
    assert normalize_email('Person+team@agency.com')=='person+team@agency.com'
    assert normalize_profile('https://www.instagram.com/Foo/?utm_source=abc')=='instagram.com:foo'
    assert normalize_profile('https://twitter.com/User/')=='x.com:user'


def test_import_idempotency_and_source_provenance(db,valid):
    v2=dict(valid,email='synthetictest@gmail.com',profile_url='https://instagram.com/test.person/',source='agency_referral')
    x=import_rows(db,[valid,v2])
    assert (x['inserted'],x['merged'])==(1,1)
    r=db.execute('SELECT * FROM leads').fetchone()
    assert json.loads(r['source_history'])==['agency_referral','community_optin']
    assert len(db.execute('SELECT * FROM leads').fetchall())==1


def test_conflicting_identity_requires_review(db,valid):
    a=dict(valid);b=dict(valid,email='newperson@example.com',profile_url='https://instagram.com/different')
    import_rows(db,[a,b]);m=dict(a,email='newperson@example.com',profile_url=a['profile_url'])
    report=import_rows(db,[m]);assert report['conflicts']==1
    assert db.execute('SELECT count(*) FROM leads').fetchone()[0]==2


def test_score_explainable_and_missing_us_evidence(valid):
    s,g,ev=grade_row(valid)
    assert g=='A' and s>=80 and len(ev)>=3
    weak=dict(valid,us_case_url='',us_audience_pct='0',conversion_case_url='',posts_per_week='0',platform='TikTok')
    s,g,ev=grade_row(weak)
    assert g=='C' and 'US-market evidence needs review' in ev


def test_draft_human_gate_and_suppression(db,valid):
    imported=import_rows(db,[valid]);lid=db.execute('SELECT id FROM leads').fetchone()['id']
    with pytest.raises(ValueError,match='Approve'):
        set_status(db,lid,'qualified');set_status(db,lid,'drafted');set_status(db,lid,'contacted')
    r=get_lead(db,lid);d=draft_message(r)
    assert 'No guaranteed earnings' in d and 'reply "no"' in d
    db.execute('UPDATE leads SET draft=?,draft_approved=1 WHERE id=?',(d,lid));db.commit()
    assert set_status(db,lid,'contacted')['status']=='contacted'
    set_status(db,lid,'opted_out')
    assert import_rows(db,[dict(valid,source='other')])['suppressed']==1
    with pytest.raises(ValueError,match='cannot be reversed'):
        set_status(db,lid,'qualified')


def test_join_requires_verifications_and_activation_evidence(db,valid):
    import_rows(db,[valid]);lid=db.execute('SELECT id FROM leads').fetchone()['id']
    db.execute("UPDATE leads SET status='approved' WHERE id=?",(lid,));db.commit()
    with pytest.raises(ValueError,match='Join gate'):
        set_status(db,lid,'joined')
    set_flags(db,lid,{'verified_us':True,'community_joined':True,'application_reviewed':True})
    assert set_status(db,lid,'joined')['status']=='joined'
    with pytest.raises(ValueError,match='Activation gate'):
        set_status(db,lid,'activated')
    set_flags(db,lid,{'creator_created':True,'first_post_url':'https://social.example/real-post'})
    assert set_status(db,lid,'activated')['status']=='activated'
    assert stats(db)['pipeline']['activated']==1


def test_csv_rejects_invalid_and_dedupes(db,valid):
    buf=io.StringIO();w=csv.DictWriter(buf,fieldnames=list(valid));w.writeheader();w.writerow(valid)
    w.writerow(dict(valid,email='synthetictest@gmail.com'))
    w.writerow(dict(valid,email='wrong-email',profile_url=''))
    r=import_csv(db,buf.getvalue());assert (r['total'],r['inserted'],r['merged'],r['rejected'])==(3,1,1,1)
