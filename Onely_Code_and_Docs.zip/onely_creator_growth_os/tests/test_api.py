import pytest
from fastapi.testclient import TestClient
import core
from app import app

@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setattr(core,'DB_PATH',tmp_path/'api.sqlite')
    with TestClient(app) as c:yield c


def test_empty_dashboard_and_page(client):
    assert client.get('/').status_code==200
    assert client.get('/apply').status_code==200
    assert client.get('/api/stats').json()['total']==0


def test_application_requires_consent_and_human_review(client):
    p={'name':'Test Synthetic','email':'synthetic@example.com','platform':'TikTok',
       'profile_url':'https://instagram.com/synthetic','source':'self_apply',
       'us_case_url':'https://example.com/us','age_18_confirmed':True,'consent_contact':True}
    assert client.post('/api/applications',json=dict(p,age_18_confirmed=False)).status_code==422
    resp=client.post('/api/applications',json=p)
    assert resp.status_code==200 and resp.json()['review']=='pending'
    lid=resp.json()['application_id']
    assert client.get('/api/leads/'+lid).json()['status']=='applied'
    assert client.patch('/api/leads/'+lid+'/status',json={'status':'approved'}).status_code==409
    assert client.patch('/api/leads/'+lid+'/flags',json={'application_reviewed':True}).status_code==200
    assert client.patch('/api/leads/'+lid+'/status',json={'status':'approved'}).status_code==200
    assert client.patch('/api/leads/'+lid+'/status',json={'status':'joined'}).status_code==409


def test_api_import_approval_and_no_auto_send(client):
    rows=[{'name':'Operator A','email':'operatora@example.com','platform':'TikTok, Instagram',
          'profile_url':'https://instagram.com/operatora','source':'agency_referral',
          'us_case_url':'https://example.com/us','posts_per_week':5}]
    r=client.post('/api/leads/upsert',json={'leads':rows});assert r.json()['inserted']==1
    lid=client.get('/api/leads').json()[0]['id']
    assert client.patch('/api/leads/'+lid+'/status',json={'status':'qualified'}).status_code==200
    d=client.post('/api/leads/'+lid+'/draft',json={'channel':'email'})
    assert d.status_code==200 and d.json()['no_auto_send']
    assert client.patch('/api/leads/'+lid+'/status',json={'status':'contacted'}).status_code==409
    assert client.post('/api/leads/'+lid+'/approve-draft').status_code==200
    assert client.patch('/api/leads/'+lid+'/status',json={'status':'contacted'}).status_code==200
